# Charging Station — Frontend

Simple React + Vite + TypeScript frontend for the Charging Station dashboard.

## Prerequisites

- Node.js v18+ and npm
- A backend API (optional) — update endpoints in `src/api` if needed

## Setup and run (development)

1. Open PowerShell in the project root (`d:\ChargingStation\charging_station_fe`).
2. Install dependencies:

   ```bash
   npm install
   ```

3. Start dev server:

   ```bash
   npm run dev
   ```

4. Open `http://localhost:5173` in your browser.

## Build for production

1. Build:

   ```bash
   npm run build
   ```

2. Preview the production build:

   ```bash
   npm run preview
   ```

## Linting

- Run: `npm run lint`

## Notes

- To change the API base URL, edit files in `src/api/`.
- If the navbar still shows Login after logging in, make sure the app state updates `isAdmin` and that `Navbar` receives the `isAdmin` prop.

## Project structure

- `src/` — source code
- `src/components` — UI components
- `src/api` — API helpers
- `public/` — static assets
- `package.json` — scripts & deps

Need a .env example or backend mock? I can add one.
