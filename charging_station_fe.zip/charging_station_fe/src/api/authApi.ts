import axios from 'axios';

export async function login(username: string, password: string): Promise<boolean> {
  try {
    await axios.post('http://localhost:3000/auth/login', { username, password });
    return true;
  } catch {
    return false;
  }
}
