import axios from 'axios';

export interface Station {
  id: number;
  stationName: string;
  locationAddress: string;
  pinCode: string;
  connectorType: string;
  status: string;
  image: string;
  locationLink: string;
}

export async function fetchStations(): Promise<Station[]> {
  const res = await axios.get('http://localhost:3000/station');
  return res.data;
}
