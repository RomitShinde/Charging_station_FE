import { useState } from 'react';

interface LoginPopupProps {
  onClose: () => void;
  onLogin: (username: string, password: string) => void;
}

const LoginPopup = ({ onClose, onLogin }: LoginPopupProps) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('http://localhost:3000/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    if (res.ok) {
      onLogin(username, password);
      onClose();
    } else {
      setError('Invalid credentials');
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-lg p-8 w-full max-w-sm relative">
        <button className="absolute top-2 right-2 text-gray-400 hover:text-gray-400 text-xxl !bg-inherit hover:!border-blue" onClick={onClose}>&times;</button>
        <h2 className="text-xl font-bold mb-4 text-blue-700 text-center ">Admin Login</h2>
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <input type="text" placeholder="Username" value={username} onChange={e => setUsername(e.target.value)} className="border rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400" required />
          <input type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} className="border rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400" required />
          {error && <div className="text-red-500 text-sm text-center">{error}</div>}
          <button type="submit" className="!bg-blue-700 text-white py-2 rounded font-semibold hover:bg-blue-700 transition">Login</button>
        </form>
      </div>
    </div>
  );
};

export default LoginPopup;
