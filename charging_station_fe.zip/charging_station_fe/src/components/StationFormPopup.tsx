import { useState } from 'react';
import type { Station } from '../api/stationApi';
import axios from 'axios';

interface StationFormPopupProps {
  onClose: () => void;
  onSubmit: (station: Station) => void;
  initialData?: Partial<Station>;
}

const defaultValues = {
  stationName: '',
  locationAddress: '',
  pinCode: '',
  connectorType: '',
  status: '',
  image: '',
  locationLink: '',
};

const StationFormPopup = ({ onClose, onSubmit, initialData }: StationFormPopupProps) => {
  const [form, setForm] = useState({ ...defaultValues, ...initialData });
  const [error, setError] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      let res;
      if (initialData && initialData.id) {
        res = await axios.patch(`http://localhost:3000/station/${initialData.id}`, form);
      } else {
        res = await axios.post('http://localhost:3000/station', form);
      }
      onSubmit(res.data.station || res.data);
      onClose();
    } catch (err) {
      setError('Failed to save station');
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-lg p-8 w-full max-w-lg relative">
        <button className="absolute top-2 right-2 text-gray-700 hover:text-gray-800 text-xl !bg-inherit rounded-xl " onClick={onClose}>&times;</button>
        <h2 className="text-xl font-bold mb-4 text-blue-700  text-center">{initialData?.id ? 'Update Station' : 'Create Station'}</h2>
        <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-4">
          <input name="stationName" value={form.stationName} onChange={handleChange} placeholder="Station Name" className="border rounded px-3 py-2" required />
          <input name="locationAddress" value={form.locationAddress} onChange={handleChange} placeholder="Location Address" className="border rounded px-3 py-2" required />
          <input name="pinCode" value={form.pinCode} onChange={handleChange} placeholder="Pin Code" className="border rounded px-3 py-2" required />
          <input name="connectorType" value={form.connectorType} onChange={handleChange} placeholder="Connector Type" className="border rounded px-3 py-2" required />
          <input name="status" value={form.status} onChange={handleChange} placeholder="Status" className="border rounded px-3 py-2" required />
          <input name="image" value={form.image} onChange={handleChange} placeholder="Image URL" className="border rounded px-3 py-2" required />
          <input name="locationLink" value={form.locationLink} onChange={handleChange} placeholder="Location Link" className="border rounded px-3 py-2" required />
          {error && <div className="text-red-500 text-sm text-center">{error}</div>}
          <button type="submit" className="!bg-blue-700 text-white py-2 rounded font-semibold hover:bg-blue-800 transition">{initialData?.id ? 'Update' : 'Create'}</button>
        </form>
      </div>
    </div>
  );
};

export default StationFormPopup;
