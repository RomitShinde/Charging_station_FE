interface NavbarProps {
  onLoginClick?: () => void;
  onLogout?: () => void;
  isAdmin?: boolean;
}

const Navbar = ({ onLoginClick, onLogout, isAdmin = false }: NavbarProps) => (
  <nav className="bg-blue-700 text-white px-8 py-4 flex justify-between items-center shadow-md">
    <div className="font-extrabold text-2xl tracking-wide">⚡ Charging Station Dashboard</div>
    {isAdmin ? (
      <button className="!bg-white text-blue-700 px-5 py-2 rounded-full font-semibold shadow hover:bg-blue-100 transition" onClick={onLogout}>Logout</button>
    ) : (
      <button className="!bg-white text-blue-700 px-5 py-2 rounded-full font-semibold shadow hover:bg-blue-100 transition" onClick={onLoginClick}>Login</button>
    )}
  </nav>
);

export default Navbar;
