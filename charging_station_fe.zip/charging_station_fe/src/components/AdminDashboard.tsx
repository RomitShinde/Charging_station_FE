import { useState } from 'react';
import type { Station } from '../api/stationApi';
import StationFormPopup from './StationFormPopup';

interface AdminDashboardProps {
  stations: Station[];
  onStationCreated: (station: Station) => void;
  onStationUpdated: (station: Station) => void;
  onRefresh: () => void;
}

const AdminDashboard = ({ stations, onStationCreated, onStationUpdated, onRefresh }: AdminDashboardProps) => {
  const [showForm, setShowForm] = useState(false);
  const [editStation, setEditStation] = useState<Station | null>(null);

  const handleCreate = () => {
    setEditStation(null);
    setShowForm(true);
  };

  const handleEdit = (station: Station) => {
    setEditStation(station);
    setShowForm(true);
  };

  const handleFormSubmit = (station: Station) => {
    if (editStation) {
      onStationUpdated(station);
    } else {
      onStationCreated(station);
    }
    onRefresh();
  };

  return (
    <div className="max-w-7xl mx-auto py-10 px-4">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-3xl font-bold text-grey-800">Admin Dashboard</h2>
        <button className="bg-blue-700 text-white px-5 py-2 rounded-full font-semibold shadow hover:bg-blue-800 transition" onClick={handleCreate}>+ Create Station</button>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {stations.length === 0 ? (
          <div className="col-span-3 text-center text-gray-500 text-lg">No stations found.</div>
        ) : (
          stations.map(station => (
            <div key={station.id} className="bg-white rounded-2xl shadow-lg p-6 flex flex-col items-center hover:scale-[1.03] transition relative">
              <button className="absolute top-3 right-3 !p-2 !border-blue-800 text-blue-700 hover:text-blue-800 hover:!bg-blue-800 !bg-inherit hover:!text-white" title="Edit Station" onClick={() => handleEdit(station)}>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-6 h-6">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M16.862 3.487a2.25 2.25 0 113.182 3.182l-9.193 9.193a4.5 4.5 0 01-1.591 1.02l-3.01 1.003 1.003-3.01a4.5 4.5 0 011.02-1.591l9.193-9.193z" />
                </svg>
              </button>
              <img src={station.image} alt={station.stationName} className="h-40 w-full object-cover rounded-xl mb-4 border border-blue-100" />
              <h3 className="text-xl font-bold mb-2 text-blue-700 text-center">{station.stationName}</h3>
              <p className="text-gray-700 mb-1 text-center">{station.locationAddress}, {station.pinCode}</p>
              <p className="text-gray-600 mb-1">Connector: <span className="font-medium">{station.connectorType}</span></p>
              <p className="text-gray-600 mb-1">Status: <span className={`font-semibold ${station.status === 'Operational' ? 'text-green-600' : 'text-red-600'}`}>{station.status}</span></p>
              <a href={station.locationLink} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:text-blue-700 mt-3 underline font-medium">View on Map</a>
            </div>
          ))
        )}
      </div>
      {showForm && (
        <StationFormPopup
          onClose={() => setShowForm(false)}
          onSubmit={handleFormSubmit}
          initialData={editStation || undefined}
        />
      )}
    </div>
  );
};

export default AdminDashboard;
