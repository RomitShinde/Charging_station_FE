import { useEffect, useState } from 'react';
import Navbar from './components/Navbar';
import LoginPopup from './components/LoginPopup';
import AdminDashboard from './components/AdminDashboard';
import { fetchStations } from './api/stationApi';
import type { Station } from './api/stationApi';
import { login as loginApi } from './api/authApi';

function App() {
  const [stations, setStations] = useState<Station[]>([]);
  const [showLogin, setShowLogin] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [visitCount, setVisitCount] = useState(0);

  const refreshStations = () => {
    fetchStations().then(setStations).catch(() => setStations([]));
  };

  useEffect(() => {
    refreshStations();
  }, []);

  useEffect(() => {
    const id = setInterval(() => setVisitCount(c => c + 1), 1000);
    return () => clearInterval(id);
  }, []);

  const handleLogin = async (username: string, password: string) => {
    const success = await loginApi(username, password);
    if (success) setIsAdmin(true);
  };

  const handleStationCreated = () => {
    refreshStations();
  };

  const handleStationUpdated = () => {
    refreshStations();
  };

  if (isAdmin) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100">
        <Navbar isAdmin onLogout={() => { setIsAdmin(false); setShowLogin(false); }} />
        <AdminDashboard
          stations={stations}
          onStationCreated={handleStationCreated}
          onStationUpdated={handleStationUpdated}
          onRefresh={refreshStations}
        />
        <div className="fixed bottom-4 right-4 bg-white/80 backdrop-blur rounded-full px-4 py-2 shadow-md text-sm text-blue-700 font-medium">
          Customer Visits: <span className='text-black'>{visitCount}</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100">
      <Navbar onLoginClick={() => setShowLogin(true)} />
      <div className="max-w-7xl mx-auto py-10 px-4">
        <h2 className="text-3xl font-bold mb-8 text-blue-800 text-center">All Charging Stations</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {stations.length === 0 ? (
            <div className="col-span-3 text-center text-gray-500 text-lg">No stations found.</div>
          ) : (
            stations.map(station => (
              <div key={station.id} className="bg-white rounded-2xl shadow-lg p-6 flex flex-col items-center hover:scale-[1.03] transition">
                <img src={station.image} alt={station.stationName} className="h-40 w-full object-cover rounded-xl mb-4 border border-blue-100" />
                <h3 className="text-xl font-bold mb-2 text-blue-700 text-center">{station.stationName}</h3>
                <p className="text-gray-700 mb-1 text-center">{station.locationAddress}, {station.pinCode}</p>
                <p className="text-gray-600 mb-1">Connector: <span className="font-medium">{station.connectorType}</span></p>
                <p className="text-gray-600 mb-1">Status: <span className={`font-semibold ${station.status === 'Operational' ? 'text-green-600' : 'text-red-600'}`}>{station.status}</span></p>
                <a href={station.locationLink} target="_blank" rel="noopener noreferrer" className="text-blue-500 mt-3 underline font-medium">View on Map</a>
              </div>
            ))
          )}
        </div>
      </div>
      {showLogin && (
        <LoginPopup onClose={() => setShowLogin(false)} onLogin={handleLogin} />
      )}
      <div className="fixed bottom-4 right-4 bg-white/80 backdrop-blur rounded-full px-4 py-2 shadow-md text-sm text-blue-700 font-medium">
        Customer Visits: <span className='text-black'>{visitCount}</span>
      </div>
    </div>
  );
}

export default App;
